
package takehome2;

/**
 *
 * @author Flranklin
 */
import java.util.Scanner;
// this is my  Abstract class created
 
public abstract class EstateAgent {
    public  String agentName;
    public  double propertyPrice;
    public double getcommission;
// this is my construtor 
    public EstateAgent(String agentName, double propertyPrice) {
        this.agentName = agentName;
        this.propertyPrice = propertyPrice;
    }
// here where my methods start 
    public String getAgentName() {
        return agentName;
    }

    public double getPropertyPrice() {
        return propertyPrice;
    }

    public double getAgentCommission() {
        return 0.2 * propertyPrice;
    }
}
// EstateAgentSales  class was created  to extend the EstateAgent class  to extend the 

 
class EstateAgentSales extends EstateAgent {
    public EstateAgentSales(String agentName, double propertySaleAmount) {
        super(agentName, propertySaleAmount);
    }
// this is my print report class 
    public void printPropertyReport() {
        System.out.println("**************************************");
        System.out.println( " your Estate Agent Name is : " + getAgentName());
        System.out.println(" Your Property Sale Price is : R" + getPropertyPrice());
        System.out.println(" Your Estate Agent Commission is R : " + getAgentCommission());
    }
}

class RunApplication {
    public static void main(String[] args) {
        // this is where i start by inputing stufff
        
        Scanner scanner = new Scanner(System.in);
        System.out.println("welcome ");
        System.out.print("Enter Estate Agent Name: ");
        String agentName = scanner.nextLine();
        System.out.print("Enter Property Sale Amount: ");
        double propertySaleAmount = scanner.nextDouble();

        EstateAgentSales estateAgentSales = new EstateAgentSales(agentName, propertySaleAmount);
        estateAgentSales.printPropertyReport();
        
        // thank you sir 
    }
}
